package com.qq.tarkovhealthfxlab.client.screen;

import com.qq.tarkovhealthfxlab.client.BodyEffect;
import com.qq.tarkovhealthfxlab.client.HealthFxClientConfig;
import com.qq.tarkovhealthfxlab.client.HealthFxController;
import com.qq.tarkovhealthfxlab.client.HealthFxPreset;
import com.qq.tarkovhealthfxlab.client.HealthFxSource;
import com.qq.tarkovhealthfxlab.client.overlay.HealthOverlayRenderer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

public final class HealthFxLabScreen extends Screen {
    private static final int CONTROL_WIDTH = 154;
    private Button sourceButton;
    private Button regionButton;
    private Button bleedButton;
    private Button fractureButton;
    private Button painkillerButton;
    private Button chromaticButton;
    private Button heartbeatButton;
    private Button contrastButton;
    private ValueSlider painSlider;
    private ValueSlider healthSlider;

    public HealthFxLabScreen() {
        super(Component.translatable("screen.tarkov_health_fx_lab.title"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - CONTROL_WIDTH - 4;
        int right = this.width / 2 + 4;
        int y = 58;

        this.sourceButton = addRenderableWidget(button(left, y, this::sourceText, ignored -> {
            HealthFxController.cycleSource();
            refreshControls();
        }));
        this.regionButton = addRenderableWidget(button(right, y, this::regionText, ignored -> {
            HealthFxController.cycleSelectedRegion();
            refreshControls();
        }));

        y += 24;
        this.bleedButton = addRenderableWidget(button(left, y, this::bleedText, ignored -> {
            if (HealthFxController.isMock()) HealthFxController.cycleBleeding();
            refreshControls();
        }));
        this.fractureButton = addRenderableWidget(button(right, y, this::fractureText, ignored -> {
            if (HealthFxController.isMock()) HealthFxController.toggleFracture();
            refreshControls();
        }));

        y += 24;
        this.painSlider = addRenderableWidget(new ValueSlider(
                left, y, CONTROL_WIDTH, "screen.tarkov_health_fx_lab.pain",
                () -> HealthFxController.selectedMockEffect().pain() / 100.0D,
                value -> HealthFxController.setPain(value * 100.0D), true));
        this.healthSlider = addRenderableWidget(new ValueSlider(
                right, y, CONTROL_WIDTH, "screen.tarkov_health_fx_lab.health",
                () -> HealthFxController.mockState().healthRatio(),
                HealthFxController::setHealthRatio, true));

        y += 24;
        this.painkillerButton = addRenderableWidget(button(left, y, this::painkillerText, ignored -> {
            if (HealthFxController.isMock()) HealthFxController.togglePainkiller();
            refreshControls();
        }));
        addRenderableWidget(button(right, y, this::screenModeText, ignored -> {
            HealthFxClientConfig.SCREEN_EFFECTS.set(HealthFxClientConfig.SCREEN_EFFECTS.get().next());
            refreshControls();
        }));

        y += 24;
        addRenderableWidget(button(left, y, this::audioText, ignored -> {
            HealthFxClientConfig.AUDIO_ENABLED.set(!HealthFxClientConfig.AUDIO_ENABLED.get());
            refreshControls();
        }));
        addRenderableWidget(button(right, y, this::motionText, ignored -> {
            HealthFxClientConfig.REDUCE_MOTION.set(!HealthFxClientConfig.REDUCE_MOTION.get());
            refreshControls();
        }));

        y += 24;
        this.chromaticButton = addRenderableWidget(button(left, y, this::chromaticText, ignored -> {
            HealthFxClientConfig.CHROMATIC_OFFSET.set(!HealthFxClientConfig.CHROMATIC_OFFSET.get());
            refreshControls();
        }));
        this.heartbeatButton = addRenderableWidget(button(right, y, this::heartbeatText, ignored -> {
            HealthFxClientConfig.DISABLE_HEARTBEAT.set(!HealthFxClientConfig.DISABLE_HEARTBEAT.get());
            refreshControls();
        }));

        y += 24;
        this.contrastButton = addRenderableWidget(button(left, y, this::contrastText, ignored -> {
            HealthFxClientConfig.HIGH_CONTRAST.set(!HealthFxClientConfig.HIGH_CONTRAST.get());
            refreshControls();
        }));

        y += 24;
        addRenderableWidget(new ValueSlider(
                left, y, CONTROL_WIDTH, "screen.tarkov_health_fx_lab.intensity",
                HealthFxClientConfig.MASTER_INTENSITY::get,
                HealthFxClientConfig.MASTER_INTENSITY::set, false));
        addRenderableWidget(new ValueSlider(
                right, y, CONTROL_WIDTH, "screen.tarkov_health_fx_lab.camera",
                HealthFxClientConfig.CAMERA_INTENSITY::get,
                HealthFxClientConfig.CAMERA_INTENSITY::set, false));

        y += 31;
        int presetWidth = 100;
        int presetGap = 4;
        int presetLeft = this.width / 2 - (presetWidth * 3 + presetGap * 2) / 2;
        HealthFxPreset[] presets = HealthFxPreset.values();
        for (int index = 0; index < presets.length; index++) {
            HealthFxPreset preset = presets[index];
            int px = presetLeft + (index % 3) * (presetWidth + presetGap);
            int py = y + (index / 3) * 22;
            addRenderableWidget(Button.builder(presetText(preset), ignored -> {
                        HealthFxController.applyPreset(preset);
                        refreshControls();
                    })
                    .bounds(px, py, presetWidth, 20)
                    .build());
        }

        int doneY = Math.min(this.height - 28, y + 51);
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), ignored -> onClose())
                .bounds(this.width / 2 - 75, doneY, 150, 20)
                .build());
        refreshControls();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        HealthOverlayRenderer.render(graphics, partialTick, this.width, this.height, false);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 16, 0xFFF2F2F2);
        Component sourceStatus = HealthFxController.source() == HealthFxSource.MOCK
                ? Component.translatable("healthfx.live.mock")
                : Component.translatable(HealthFxController.liveStatusKey());
        graphics.drawCenteredString(this.font, sourceStatus, this.width / 2, 34, 0xFF9BC8C3);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private Button button(int x, int y, TextSupplier text, Button.OnPress action) {
        return Button.builder(text.get(), action).bounds(x, y, CONTROL_WIDTH, 20).build();
    }

    private void refreshControls() {
        if (this.sourceButton == null) return;
        this.sourceButton.setMessage(sourceText());
        this.regionButton.setMessage(regionText());
        this.bleedButton.setMessage(bleedText());
        this.fractureButton.setMessage(fractureText());
        this.painkillerButton.setMessage(painkillerText());
        this.chromaticButton.setMessage(chromaticText());
        this.heartbeatButton.setMessage(heartbeatText());
        this.contrastButton.setMessage(contrastText());
        boolean mock = HealthFxController.isMock();
        this.regionButton.active = mock;
        this.bleedButton.active = mock;
        this.fractureButton.active = mock;
        this.painkillerButton.active = mock;
        this.painSlider.active = mock;
        this.healthSlider.active = mock;
        this.painSlider.sync();
        this.healthSlider.sync();
    }

    private Component sourceText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.source",
                Component.translatable(HealthFxController.source() == HealthFxSource.MOCK
                        ? "healthfx.source.mock" : "healthfx.source.tarkov"));
    }

    private Component regionText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.part",
                Component.translatable("healthfx.part." + HealthFxController.selectedRegion().id()));
    }

    private Component bleedText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.bleed",
                Component.translatable("healthfx.bleed."
                        + HealthFxController.selectedMockEffect().bleeding().name().toLowerCase()));
    }

    private Component fractureText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.fracture",
                onOff(HealthFxController.selectedMockEffect().fractured()));
    }

    private Component painkillerText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.painkiller",
                onOff(HealthFxController.mockState().painkillerActive()));
    }

    private Component screenModeText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.screen_fx",
                Component.translatable("healthfx.mode."
                        + HealthFxClientConfig.SCREEN_EFFECTS.get().name().toLowerCase()));
    }

    private Component audioText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.audio",
                onOff(HealthFxClientConfig.AUDIO_ENABLED.get()));
    }

    private Component motionText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.reduce_motion",
                onOff(HealthFxClientConfig.REDUCE_MOTION.get()));
    }

    private Component chromaticText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.chromatic",
                onOff(HealthFxClientConfig.CHROMATIC_OFFSET.get()));
    }

    private Component heartbeatText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.heartbeat",
                onOff(!HealthFxClientConfig.DISABLE_HEARTBEAT.get()));
    }

    private Component contrastText() {
        return Component.translatable(
                "screen.tarkov_health_fx_lab.contrast",
                onOff(HealthFxClientConfig.HIGH_CONTRAST.get()));
    }

    private static Component presetText(HealthFxPreset preset) {
        return Component.translatable("healthfx.preset." + preset.name().toLowerCase());
    }

    private static Component onOff(boolean value) {
        return Component.translatable(value ? "options.on" : "options.off");
    }

    @FunctionalInterface
    private interface TextSupplier {
        Component get();
    }

    private static final class ValueSlider extends AbstractSliderButton {
        private final String translationKey;
        private final DoubleSupplier reader;
        private final DoubleConsumer writer;
        private final boolean percentValue;

        private ValueSlider(
                int x,
                int y,
                int width,
                String translationKey,
                DoubleSupplier reader,
                DoubleConsumer writer,
                boolean percentValue
        ) {
            super(x, y, width, 20, Component.empty(), clamp(reader.getAsDouble()));
            this.translationKey = translationKey;
            this.reader = reader;
            this.writer = writer;
            this.percentValue = percentValue;
            updateMessage();
        }

        private void sync() {
            this.value = clamp(this.reader.getAsDouble());
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            long shown = Math.round(this.value * 100.0D);
            setMessage(Component.translatable(this.translationKey, shown));
        }

        @Override
        protected void applyValue() {
            this.writer.accept(clamp(this.value));
        }

        private static double clamp(double value) {
            return Math.max(0.0D, Math.min(1.0D, value));
        }
    }
}

package com.qq.tarkovhealthfxlab.client;

import com.qq.tarkovhealthfxlab.client.audio.HealthSoundController;
import com.qq.tarkovhealthfxlab.compat.tarkov.TarkovLiveStateProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

public final class HealthFxController {
    private static HealthFxSource source = HealthFxSource.MOCK;
    private static BodyRegion selectedRegion = BodyRegion.LEFT_LEG;
    private static HealthFxState mockState = HealthFxState.healthy();
    private static HealthFxState displayedState = mockState;
    private static EffectChannels smoothedChannels = EffectChannels.from(mockState);
    private static String liveStatusKey = "healthfx.live.mod_missing";
    private static long clientTicks;

    private HealthFxController() {
    }

    public static void tick(Minecraft minecraft) {
        clientTicks++;
        LocalPlayer player = minecraft.player;
        if (source == HealthFxSource.TARKOV_LIVE) {
            TarkovLiveStateProvider.Result result = TarkovLiveStateProvider.sample(player);
            liveStatusKey = result.statusKey();
            displayedState = result.state().orElse(HealthFxState.healthy());
        } else {
            displayedState = mockState;
            liveStatusKey = "healthfx.live.mock";
        }

        EffectChannels target = EffectChannels.from(displayedState);
        smoothedChannels = EffectChannels.interpolate(smoothedChannels, target, 0.14D);
        boolean moving = isMoving(player);
        boolean onGround = player != null && player.onGround();
        HealthSoundController.tick(minecraft, displayedState, smoothedChannels, moving, onGround, clientTicks);
    }

    public static HealthFxFrame frame(float partialTick) {
        double timeSeconds = (clientTicks + Math.max(0.0F, partialTick)) / 20.0D;
        LocalPlayer player = Minecraft.getInstance().player;
        return HealthEffectModel.evaluate(
                smoothedChannels,
                timeSeconds,
                isMoving(player),
                player != null && player.onGround(),
                HealthFxClientConfig.MASTER_INTENSITY.get(),
                HealthFxClientConfig.SCREEN_EFFECTS.get() == HealthFxClientConfig.ScreenEffectsMode.LOW,
                HealthFxClientConfig.REDUCE_MOTION.get(),
                HealthFxClientConfig.CAMERA_INTENSITY.get()
        );
    }

    public static void resetSession() {
        displayedState = HealthFxState.healthy();
        smoothedChannels = EffectChannels.from(displayedState);
        clientTicks = 0L;
        HealthSoundController.reset();
    }

    public static HealthFxSource source() {
        return source;
    }

    public static void setSource(HealthFxSource value) {
        source = value;
    }

    public static void cycleSource() {
        setSource(source.next());
    }

    public static BodyRegion selectedRegion() {
        return selectedRegion;
    }

    public static void cycleSelectedRegion() {
        selectedRegion = selectedRegion.next();
    }

    public static HealthFxState displayedState() {
        return displayedState;
    }

    public static HealthFxState mockState() {
        return mockState;
    }

    public static BodyEffect selectedMockEffect() {
        return mockState.effect(selectedRegion);
    }

    public static String liveStatusKey() {
        return liveStatusKey;
    }

    public static void applyPreset(HealthFxPreset preset) {
        source = HealthFxSource.MOCK;
        mockState = preset.create(mockState.revision() + 1L);
    }

    public static void cycleBleeding() {
        requireMock();
        BodyEffect before = selectedMockEffect();
        mockState = mockState.withEffect(selectedRegion, before.withBleeding(before.bleeding().next()));
    }

    public static void setBleeding(BleedingLevel level) {
        requireMock();
        mockState = mockState.withEffect(selectedRegion, selectedMockEffect().withBleeding(level));
    }

    public static void toggleFracture() {
        requireMock();
        BodyEffect before = selectedMockEffect();
        mockState = mockState.withEffect(selectedRegion, before.withFractured(!before.fractured()));
    }

    public static void setFracture(boolean fractured) {
        requireMock();
        mockState = mockState.withEffect(selectedRegion, selectedMockEffect().withFractured(fractured));
    }

    public static void setPain(double pain) {
        requireMock();
        mockState = mockState.withEffect(selectedRegion, selectedMockEffect().withPain(pain));
    }

    public static void setHealthRatio(double ratio) {
        requireMock();
        mockState = mockState.withHealthRatio(Math.max(0.0D, Math.min(1.0D, ratio)));
    }

    public static void togglePainkiller() {
        requireMock();
        mockState = mockState.withPainkillerActive(!mockState.painkillerActive());
    }

    public static boolean isMock() {
        return source == HealthFxSource.MOCK;
    }

    private static boolean isMoving(LocalPlayer player) {
        return player != null && player.getDeltaMovement().horizontalDistanceSqr() > 0.0004D;
    }

    private static void requireMock() {
        if (source != HealthFxSource.MOCK) {
            throw new IllegalStateException("mock controls are unavailable while the live source is selected");
        }
    }
}

package com.qq.tarkovhealthfxlab;

import com.qq.tarkovhealthfxlab.client.HealthFxClientConfig;
import com.qq.tarkovhealthfxlab.client.audio.ModSounds;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(TarkovHealthFxLab.MODID)
public final class TarkovHealthFxLab {
    public static final String MODID = "tarkov_health_fx_lab";

    public TarkovHealthFxLab() {
        ModSounds.SOUND_EVENTS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, HealthFxClientConfig.SPEC);
    }
}

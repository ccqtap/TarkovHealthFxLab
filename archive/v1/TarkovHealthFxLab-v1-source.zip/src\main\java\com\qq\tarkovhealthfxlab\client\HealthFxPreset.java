package com.qq.tarkovhealthfxlab.client;

import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

public enum HealthFxPreset {
    OFF,
    LIGHT_BLEED,
    HEAVY_BLEED,
    FRACTURE_LEG,
    PAIN_HIGH,
    CRITICAL_MIXED;

    public HealthFxState create(long revision) {
        Map<BodyRegion, BodyEffect> effects = new EnumMap<>(BodyRegion.class);
        double healthRatio = 1.0D;
        switch (this) {
            case OFF -> {
            }
            case LIGHT_BLEED -> {
                effects.put(BodyRegion.LEFT_ARM, new BodyEffect(BleedingLevel.LIGHT, false, 12.0D));
                healthRatio = 0.82D;
            }
            case HEAVY_BLEED -> {
                effects.put(BodyRegion.STOMACH, new BodyEffect(BleedingLevel.HEAVY, false, 42.0D));
                healthRatio = 0.55D;
            }
            case FRACTURE_LEG -> {
                effects.put(BodyRegion.LEFT_LEG, new BodyEffect(BleedingLevel.NONE, true, 48.0D));
                healthRatio = 0.70D;
            }
            case PAIN_HIGH -> {
                effects.put(BodyRegion.THORAX, new BodyEffect(BleedingLevel.NONE, false, 82.0D));
                healthRatio = 0.65D;
            }
            case CRITICAL_MIXED -> {
                effects.put(BodyRegion.LEFT_LEG, new BodyEffect(BleedingLevel.HEAVY, true, 88.0D));
                effects.put(BodyRegion.RIGHT_ARM, new BodyEffect(BleedingLevel.LIGHT, true, 64.0D));
                healthRatio = 0.22D;
            }
        }
        return HealthFxState.restore(effects, healthRatio, false, Math.max(0L, revision));
    }

    public static HealthFxPreset parse(String value) {
        return valueOf(value.trim().toUpperCase(Locale.ROOT).replace('-', '_'));
    }
}

package com.qq.tarkovhealthfxlab.client;

import java.util.Locale;

public enum BodyRegion {
    HEAD("head"),
    THORAX("thorax"),
    STOMACH("stomach"),
    LEFT_ARM("left_arm"),
    RIGHT_ARM("right_arm"),
    LEFT_LEG("left_leg"),
    RIGHT_LEG("right_leg");

    private final String id;

    BodyRegion(String id) {
        this.id = id;
    }

    public String id() {
        return this.id;
    }

    public boolean isArm() {
        return this == LEFT_ARM || this == RIGHT_ARM;
    }

    public boolean isLeg() {
        return this == LEFT_LEG || this == RIGHT_LEG;
    }

    public BodyRegion next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public static BodyRegion parse(String value) {
        String normalized = value.trim().toUpperCase(Locale.ROOT).replace('-', '_');
        return valueOf(normalized);
    }
}

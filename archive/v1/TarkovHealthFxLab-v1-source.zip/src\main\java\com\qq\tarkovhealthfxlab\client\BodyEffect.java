package com.qq.tarkovhealthfxlab.client;

import java.util.Objects;

public record BodyEffect(BleedingLevel bleeding, boolean fractured, double pain) {
    public static final BodyEffect NONE = new BodyEffect(BleedingLevel.NONE, false, 0.0D);

    public BodyEffect {
        Objects.requireNonNull(bleeding, "bleeding");
        if (!Double.isFinite(pain) || pain < 0.0D || pain > 100.0D) {
            throw new IllegalArgumentException("pain must be finite and in [0, 100]");
        }
        pain = Math.rint(pain * 10.0D) / 10.0D;
    }

    public boolean active() {
        return bleeding != BleedingLevel.NONE || fractured || pain > 0.0D;
    }

    public BodyEffect withBleeding(BleedingLevel value) {
        return new BodyEffect(value, fractured, pain);
    }

    public BodyEffect withFractured(boolean value) {
        return new BodyEffect(bleeding, value, pain);
    }

    public BodyEffect withPain(double value) {
        return new BodyEffect(bleeding, fractured, value);
    }
}

# Tarkov Health FX Lab v1

这是一个独立的 Minecraft Forge 1.20.1 客户端测试模组（版本 `v1`），用来验收 TarkovMod 的“流血 / 骨折 / 疼痛”第一人称表现。它不会修改 `E:\Project\TarkovMod`，默认也不要求 TarkovMod 存在。

当前 v1 的视觉与音频实现已经封存，后续候选模组调研和替换实验应在新分支/新版本中进行，不直接改写 v1 资源。

文档第 7 条对应的 v2 目标、兼容边界和验收矩阵见 [`docs/V2-DOCUMENT-ITEM-7-SPEC.md`](docs/V2-DOCUMENT-ITEM-7-SPEC.md)。第三方模组只在用户确认候选方案后作为外部依赖/API 接入；在此之前不会把其资源复制进项目。

候选效果、官方预览和许可证边界见 [`docs/REUSE-CANDIDATES.md`](docs/REUSE-CANDIDATES.md)。

## 快速测试

```powershell
Set-Location 'E:\Project\TarkovHealthFxLab'
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-17.0.19.10-hotspot'
.\gradlew.bat clean test build
```

只测试美术预览时运行 `runClient`，进入世界后按 `F8`。实验室中的 `Mock` 来源不会写入服务器、存档或玩家能力。

支持的客户端命令：

```text
/healthfx ui
/healthfx preset off|light_bleed|heavy_bleed|fracture_leg|pain_high|critical_mixed
/healthfx part head|thorax|stomach|left_arm|right_arm|left_leg|right_leg
/healthfx bleed none|light|heavy
/healthfx fracture true|false
/healthfx pain 0..100
/healthfx health 0..100
/healthfx painkiller true|false
/healthfx source mock|tarkov
```

## Tarkov 实时联调

先确认 `E:\Project\TarkovMod\build\libs\tarkovmod-5.0.0.jar` 是要验收的版本，再运行：

```powershell
.\gradlew.bat runClient -PwithTarkov=true
```

该 profile 会额外加载 TarkovMod 5.0.0、PetiteInventory 1.0.8 和 TarkovMod 所需的 MCEF 2.1.6。进入世界后在实验室切换为 `Tarkov live`；只有收到 TarkovMod 的完整 owner-only 健康快照后才会显示实时状态。桥接全部使用反射隔离，普通 Mock 启动不会因缺少 TarkovMod 类而崩溃。

Tarkov 服务器端可用的验证命令（单人世界需开启作弊）：

```text
/tarkov health condition set @s left_leg fracture
/tarkov health condition set @s stomach heavy_bleed
/tarkov health condition set @s head pain 75
/tarkov health condition clear @s all all
```

## 表现设计

- 轻度流血：低透明度暗红外缘渗色，约 7–12 秒一次低音量脉搏，不覆盖准星中心。
- 重度流血：更厚的边缘血污和约 1 秒节律的深红呼吸，脉搏间隔约 2.8–4.2 秒。
- 骨折：首次触发短促骨裂声，边缘白灰应力裂纹；腿部移动时只有极小的落步压沉，不使用白屏、强滚转或玻璃碎裂音。
- 疼痛：按 0–100 连续变化的冷色外围波纹；高疼痛增加耳鸣和压抑呼吸，但中心保持清晰，不使用强模糊或 `nausea` 后处理。
- 屏幕效果可以 `OFF / LOW / FULL`，稳定的形状 + 文字状态卡仍可保留；颜色不是唯一信息通道。
- `Reduce motion` 会关闭镜头动态；`OFF` 也会关闭镜头动态。F8 中还可以关闭疼痛色散、流血脉搏并打开高对比度状态卡；音效有独立开关、音量和字幕。

## 资源

`textures/gui/health_fx/` 下的三张 PNG 是本项目原创生成并经过透明边缘检查的叠层。`tools/generate_original_audio.py` 使用标准库确定性合成六个 WAV，再由 FFmpeg 编码为 Ogg Vorbis；没有复用 First Aid 的 PNG、OGG、GUI 或运行时代码。

## 重要边界

这个项目只验证表现层。它不会修复 TarkovMod 当前已审计出的旧任务/配置物品 ID、出血致死与不死图腾生命周期问题，也不会把 First Aid 重新加入整合包。验收通过后，应把资源和表现逻辑以独立提交迁回主模组，并在迁回前补充稳定的客户端 health-view API。

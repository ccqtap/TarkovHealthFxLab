package com.qq.tarkovhealthfxlab.client;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

final class HealthFxStateTest {
    @Test
    void aggregatesStrongestBleedingFracturesAndVisiblePain() {
        HealthFxState state = HealthFxState.restore(Map.of(
                BodyRegion.LEFT_ARM, new BodyEffect(BleedingLevel.LIGHT, true, 35.0D),
                BodyRegion.RIGHT_LEG, new BodyEffect(BleedingLevel.HEAVY, true, 78.0D)
        ), 0.42D, false, 7L);

        assertEquals(BleedingLevel.HEAVY, state.strongestBleeding());
        assertEquals(2, state.bleedingPartCount());
        assertEquals(2, state.fractureCount());
        assertEquals(1, state.fracturedArms());
        assertEquals(1, state.fracturedLegs());
        assertEquals(78.0D, state.visiblePain());
    }

    @Test
    void painkillerSuppressesPresentationWithoutDeletingRawPain() {
        HealthFxState state = HealthFxState.restore(Map.of(
                BodyRegion.THORAX, new BodyEffect(BleedingLevel.NONE, false, 82.0D)
        ), 0.8D, true, 2L);

        assertEquals(82.0D, state.rawPain());
        assertEquals(0.0D, state.visiblePain());
        assertEquals(0.0D, EffectChannels.from(state).pain());
    }
}

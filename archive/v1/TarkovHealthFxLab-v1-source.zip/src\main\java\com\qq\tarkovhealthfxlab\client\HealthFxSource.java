package com.qq.tarkovhealthfxlab.client;

public enum HealthFxSource {
    MOCK,
    TARKOV_LIVE;

    public HealthFxSource next() {
        return this == MOCK ? TARKOV_LIVE : MOCK;
    }
}

# 资源来源与使用边界

本实验室的三张第一人称叠层使用 ImageGen 生成后做了透明边缘处理：

- `bleeding_border.png`：暗红不对称外缘血污，中心留空。
- `fracture_stress.png`：稀疏的骨白应力裂纹，仅在边缘出现。
- `pain_periphery.png`：低对比度冷色神经波纹，中心保持清晰。

六个 Ogg 音效由 `tools/generate_original_audio.py` 用标准库确定性合成，再用 FFmpeg 编码。声音设计刻意使用短促 onset、低频脉搏、受压呼吸和渐退 relief，避免持续人声循环与惊吓峰值。

这些文件是实验室自己的临时验收资源，不从 First Aid（或其兼容模组）提取或再分发任何美术、音频、GUI、代码或配置。验收通过后，迁回 TarkovMod 时应重新确认项目的最终授权、署名和音频混音规范。
